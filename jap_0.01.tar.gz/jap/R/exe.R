exe <-
function(x) {
    return(eval(parse(text=x)))
}
