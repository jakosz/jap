seq_le <-
function(x) {
    return(seq_len(length(x)-1))
}
