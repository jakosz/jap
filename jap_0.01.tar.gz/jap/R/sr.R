sr <-
function(x, ...) {
    scale_to_range(x, ...)
}
