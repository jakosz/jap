seq_en <-
function(x) {
    return(seq_len((length(x)-1))+1)
}
