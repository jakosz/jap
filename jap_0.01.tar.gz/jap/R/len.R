len <-
function(x) {
    return( length(x) )
}
