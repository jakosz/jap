ps <-
function(..., sep = '') {
    return(paste(..., sep=sep))
}
