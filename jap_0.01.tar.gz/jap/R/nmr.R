nmr <-
function(x) {
    return( as.numeric(as.character(x)) )
}
