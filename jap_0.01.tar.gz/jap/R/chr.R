chr <-
function(x) {
    return( as.character(x) )
}
