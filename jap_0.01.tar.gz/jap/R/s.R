s <-
function(...) {
    return( system(ps(...)) )
}
