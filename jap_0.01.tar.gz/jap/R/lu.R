lu <-
function(x) {
    return( length(unique(x)) )
}
