lw <-
function(...) {
    return( length(which(...)) )
}
