vs <-
function(x, sep = '') {
    return( paste(x, collapse = sep) )
}
